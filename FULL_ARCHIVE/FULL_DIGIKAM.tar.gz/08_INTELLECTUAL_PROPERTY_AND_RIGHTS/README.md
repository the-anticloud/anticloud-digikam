# 08 Intellectual Property And Rights

**Project:** DIGIKAM
**Upstream:** https://github.com/digiKam/digikam

Content specific to DIGIKAM in category CAMERAS.
