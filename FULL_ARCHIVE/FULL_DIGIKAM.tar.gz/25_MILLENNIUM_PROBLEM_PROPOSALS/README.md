# 25 Millennium Problem Proposals

**Project:** DIGIKAM
**Upstream:** https://github.com/digiKam/digikam

Content specific to DIGIKAM in category CAMERAS.
