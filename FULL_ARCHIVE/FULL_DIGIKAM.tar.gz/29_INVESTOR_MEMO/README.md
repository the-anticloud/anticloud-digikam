# 29 Investor Memo

**Project:** DIGIKAM
**Upstream:** https://github.com/digiKam/digikam

Content specific to DIGIKAM in category CAMERAS.
